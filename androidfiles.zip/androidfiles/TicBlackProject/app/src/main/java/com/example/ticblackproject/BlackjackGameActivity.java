package com.example.ticblackproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BlackjackGameActivity extends AppCompatActivity {

    private List<Card> deck;
    private List<Card> playerHand;
    private List<Card> dealerHand;

    private TextView playerScoreText;
    private TextView dealerScoreText;
    private TextView resultText;
    private TextView playerCardsText;
    private TextView dealerCardsText;
    private TextView playerBalanceText;
    private TextView currentBetText;

    private int playerScore;
    private int dealerScore;
    private boolean gameStarted = false;

    private Button dealButton;
    private int playerBalance = 1000; // 초기 플레이어 잔액
    private int currentBet = 0;       // 현재 베팅 금액

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blackjack_game);

        playerScoreText = findViewById(R.id.playerScore);
        dealerScoreText = findViewById(R.id.dealerScore);
        resultText = findViewById(R.id.resultText);
        playerCardsText = findViewById(R.id.playerCards);
        dealerCardsText = findViewById(R.id.dealerCards);
        playerBalanceText = findViewById(R.id.playerBalance); // 플레이어 잔액 텍스트
        currentBetText = findViewById(R.id.currentBet);       // 현재 베팅 금액 텍스트

        dealButton = findViewById(R.id.dealButton);
        Button hitButton = findViewById(R.id.hitButton);
        Button standButton = findViewById(R.id.standButton);

        deck = new ArrayList<>();
        playerHand = new ArrayList<>();
        dealerHand = new ArrayList<>();
        initializeDeck();

        playerBalanceText.setText("잔액: $" + playerBalance);
        currentBetText.setText("베팅 금액: $" + currentBet);

        dealButton.setOnClickListener(v -> {
            if (!gameStarted) {
                if (currentBet > 0 && currentBet <= playerBalance) {
                    startGame();
                } else {
                    resultText.setText("유효한 베팅 금액을 입력하세요.");
                }
            } else {
                resultText.setText("이미 게임이 시작되었습니다.");
            }
        });

        hitButton.setOnClickListener(v -> hit());
        standButton.setOnClickListener(v -> stand());

        // 베팅 증가 및 감소 버튼
        Button betIncreaseButton = findViewById(R.id.betIncreaseButton);
        betIncreaseButton.setOnClickListener(v -> increaseBet());

        Button betDecreaseButton = findViewById(R.id.betDecreaseButton);
        betDecreaseButton.setOnClickListener(v -> decreaseBet());

        // 게임 변경 버튼
        Button switchToTicTacToeButton = findViewById(R.id.switchToTicTacToeButton);
        switchToTicTacToeButton.setOnClickListener(v -> {
            Intent intent = new Intent(BlackjackGameActivity.this, TicTacToeActivity.class);
            startActivity(intent);
        });

        Button switchToBoardGameButton = findViewById(R.id.switchToBoardGameButton);
        switchToBoardGameButton.setOnClickListener(v -> {
            Intent intent = new Intent(BlackjackGameActivity.this, BoardGameActivity.class);
            startActivity(intent);
        });
    }

    private void initializeDeck() {
        String[] suits = {"하트", "다이아몬드", "클럽", "스페이드"};
        String[] values = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
        deck.clear();
        for (String suit : suits) {
            for (String value : values) {
                deck.add(new Card(value, suit));
            }
        }
        Collections.shuffle(deck);
    }

    private void startGame() {
        gameStarted = true;
        playerHand.clear();
        dealerHand.clear();
        resultText.setText("");
        playerCardsText.setText("카드: ");
        dealerCardsText.setText("카드: ");

        playerHand.add(deck.remove(0));
        dealerHand.add(deck.remove(0));
        playerHand.add(deck.remove(0));
        dealerHand.add(deck.remove(0));

        updateScores();
        updateCardTexts();
    }

    private void hit() {
        if (getScore(playerHand) < 21) {
            playerHand.add(deck.remove(0));
            updateScores();
            updateCardTexts();
            if (getScore(playerHand) > 21) {
                resultText.setText("플레이어 버스트! 딜러 승리!");
                playerBalance -= currentBet;
                updatePlayerBalance();
                endGame();
            }
        }
    }

    private void stand() {
        while (getScore(dealerHand) < 17) {
            dealerHand.add(deck.remove(0));
        }
        updateScores();
        updateCardTexts();

        playerScore = getScore(playerHand);
        dealerScore = getScore(dealerHand);

        if (dealerScore > 21) {
            resultText.setText("딜러 버스트! 플레이어 승리!");
            playerBalance += currentBet;
        } else if (playerScore > dealerScore) {
            resultText.setText("플레이어 승리!");
            playerBalance += currentBet;
        } else if (playerScore < dealerScore) {
            resultText.setText("딜러 승리!");
            playerBalance -= currentBet;
        } else {
            resultText.setText("푸시!");
        }
        updatePlayerBalance();
        endGame();
    }

    private void increaseBet() {
        if (currentBet < playerBalance) {
            currentBet += 50; // 베팅 증가 단위
            currentBetText.setText("베팅 금액: $" + currentBet);
        } else {
            resultText.setText("잔액이 부족합니다.");
        }
    }

    private void decreaseBet() {
        if (currentBet > 0) {
            currentBet -= 50; // 베팅 감소 단위
            currentBetText.setText("베팅 금액: $" + currentBet);
        } else {
            resultText.setText("베팅 금액은 0보다 클 수 없습니다.");
        }
    }

    private void updatePlayerBalance() {
        playerBalanceText.setText("잔액: $" + playerBalance);
    }

    private void updateScores() {
        playerScore = getScore(playerHand);
        dealerScore = getScore(dealerHand);
        playerScoreText.setText("플레이어: " + playerScore);
        dealerScoreText.setText("딜러: " + dealerScore);
    }

    private void updateCardTexts() {
        playerCardsText.setText("카드: " + getCardListText(playerHand));
        dealerCardsText.setText("카드: " + getCardListText(dealerHand));
    }

    private String getCardListText(List<Card> hand) {
        StringBuilder cardList = new StringBuilder();
        for (Card card : hand) {
            cardList.append(card).append(", ");
        }
        if (cardList.length() > 0) {
            cardList.setLength(cardList.length() - 2);
        }
        return cardList.toString();
    }

    private int getScore(List<Card> hand) {
        int score = 0;
        int aces = 0;

        for (Card card : hand) {
            if (card.value.equals("A")) {
                aces++;
                score += 11;
            } else if ( card.value.equals("K") || card.value.equals("Q") || card.value.equals("J")) {
                score += 10;
            } else {
                score += Integer.parseInt(card.value);
            }
        }

        while (score > 21 && aces > 0) {
            score -= 10;
            aces--;
        }

        return score;
    }

    private void endGame() {
        gameStarted = false;
        currentBet = 0; // 게임 종료 후 베팅 초기화
        currentBetText.setText("베팅 금액: $" + currentBet);
        resetScores();
    }

    private void resetScores() {
        playerScore = 0;
        dealerScore = 0;
        playerScoreText.setText("플레이어 점수: " + playerScore);
        dealerScoreText.setText("딜러 점수: " + dealerScore);
    }

    private static class Card {
        String value;
        String suit;

        Card(String value, String suit) {
            this.value = value;
            this.suit = suit;
        }

        @Override
        public String toString() {
            return value + " of " + suit;
        }
    }
}
